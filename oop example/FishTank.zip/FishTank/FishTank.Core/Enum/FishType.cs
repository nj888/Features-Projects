﻿namespace FishTank.Core.Enum
{
    public enum FishType
    {
        Gold,
        Angel,
        Babel
    }
}
