﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Xml;
using FishTank.Core.Enum;

namespace FishTank.Core
{
    public static class Tank
    {
        private static readonly Dictionary<FishType, int> FishInTank = new Dictionary<FishType, int>();

        static Tank()
        {
            FishInTank.Add(FishType.Angel, 0);
            FishInTank.Add(FishType.Gold, 0);
            FishInTank.Add(FishType.Babel, 0);

        }

        public static double Feed()
        {
            double totalFoodInGram = 0;

            foreach (FishType fishType in FishInTank.Keys)
            {
                totalFoodInGram += GetFishFood(fishType);
            }

            return totalFoodInGram;
        }

        private static double GetFishFood(FishType fishType)
        {
            switch (fishType)
            {
                case FishType.Angel:
                    return FishInTank[fishType] * 0.2;
                case FishType.Babel:
                    return FishInTank[fishType] * 0.3;
                case FishType.Gold:
                    return FishInTank[fishType] * 0.1;
                default:
                    throw new Exception("Unknown fish type found in tank!");
            }
        }

        public static void AddFish(FishType fishType, int numberOfFish)
        {
            FishInTank[fishType] += numberOfFish;
        }

        public static void ExportToXml(string fullFilePath)
        {
            XmlTextWriter writer = new XmlTextWriter(fullFilePath, System.Text.Encoding.UTF8);
            XmlDocument xmlDocument = new XmlDocument();
            writer.WriteStartDocument(true);
            writer.Formatting = Formatting.Indented;
            writer.Indentation = 2;
            writer.WriteStartElement("Tank");

            foreach (FishType fishType in FishInTank.Keys)
            {
                CreateXmlNode(fishType.ToString(), FishInTank[fishType], GetFishFood(fishType), writer);
            }

            writer.WriteEndElement();
            writer.WriteEndDocument();
            xmlDocument.Save(writer);
            writer.Close();

        }

        private static void CreateXmlNode(string fishType, int numberOfFish, double foodInGram, XmlTextWriter writer)
        {
            writer.WriteStartElement("Fish");
            writer.WriteStartElement("FishType");
            writer.WriteString(fishType);
            writer.WriteEndElement();
            writer.WriteStartElement("NumberOfFish");
            writer.WriteString(numberOfFish.ToString());
            writer.WriteEndElement();
            writer.WriteStartElement("FoodToFeed");
            writer.WriteString(foodInGram.ToString(CultureInfo.InvariantCulture));
            writer.WriteEndElement();
            writer.WriteEndElement();
        }
    }
}
