﻿using System;
using System.IO;
using FishTank.Core;
using FishTank.Core.Enum;
using Gu.SerializationAsserts;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FishTank.Tests
{
    [TestClass]
    public class TankTest
    {
        [TestMethod]
        public void Tank_Feed()
        {
            Tank.AddFish(FishType.Angel, 2);
            Tank.AddFish(FishType.Babel, 5);
            Tank.AddFish(FishType.Gold, 5);
            double totalFood = Tank.Feed();
            Assert.AreEqual(totalFood, 2.4);
        }


        [TestMethod]
        public void Tank_Export_XML()
        {
            double totalFood = Tank.Feed();
            Assert.AreEqual(totalFood, 2.4);
            var exportFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "fishExport.xml");
            var sampleXmlFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "fishExportSampleData.xml");

            Tank.ExportToXml(exportFilePath);

            string actualFileString = File.ReadAllText(exportFilePath);
            string expectedFileString = File.ReadAllText(sampleXmlFilePath);
            XmlAssert.Equal(expectedFileString, actualFileString, XmlAssertOptions.IgnoreDeclaration | XmlAssertOptions.IgnoreNamespaces);
        }
    }
}
